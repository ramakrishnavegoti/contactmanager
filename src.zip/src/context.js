import React, { Component } from 'react'

const Context = React.createContext();
const reducer = (state,action) => {
        switch(action.type){
            case 'DELETE_CONTACT':
            return{
                ...state,
                contacts: state.contacts.filter(contact => contact.id !== action.payload)
            };
            case 'ADD_CONTACT':
            return{
                ...state,
                contacts: [action.payload,...state.contacts]
            };
            default:
                return state;
        }
};
export class Provider extends Component {
    state = {
        contacts : [
            {
                id:1,
                name:"Ramakrishna Vegoti",
                email:"ramakris.vegoti@gmail.com",
                phone:"966-669-2068"
            },
            {
                id:2,
                name:"Nandhini Vegoti",
                  email:"nandhni.vegoti@gmail.com",
                phone:"836-737-4809"
            },
            {
                id:3,
                name:"Kurmarao Mudidana",
                email:"kurma.mudidana@gmail.com",
                phone:"970-507-4356"
            }
        ],
        dispatch: action => {this.setState(state => reducer(state,action))}
    };
    render() {
        return (
           <Context.Provider value = {this.state}>
                {this.props.children}
           </Context.Provider>
        )
    }
}
export const Consumer = Context.Consumer;
